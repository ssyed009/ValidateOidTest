package automation.helpers;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;



/**
 * Common class used to house generic methods that is used across all test suites
 */
public class common 
{

	// Config file
	public static String propFileName = null;
	
	
	public static void setTestData() throws IOException
	{
		try 
		{
			Properties prop = new Properties();
			String propFileName = System.getProperty("user.dir") + "\\src\\test\\java\\automation\\testdata\\testData.properties";
			InputStream inputStream = new FileInputStream(propFileName);
			prop.load(inputStream);

		}
		catch (Exception e)
		{
			System.out.println("Failed to load config.properties file. Exception: "  + e);
		}
	}
	
	public static Properties getPropertiesFile(String path)
	{
		Properties prop = null;
		
		try 
		{
			prop = new Properties();
			String propFileName = System.getProperty("user.dir") + path;
			InputStream inputStream = new FileInputStream(propFileName);
			prop.load(inputStream);
		}
		catch (Exception e)
		{
			System.out.println("No externalized file detected ");
		}
		
		return prop;
	}
		
	public static void createFailureReport(ITestResult results, WebDriver driver) throws IOException
	{
		if(results.getStatus() == ITestResult.FAILURE || results.getStatus() == ITestResult.SKIP)
		{
			 
			 if(results.getStatus() == ITestResult.FAILURE)
			 {
				 System.err.println(results.getName() + " @ " + LocalTime.now() + " FAILED");
			 }
			 else
			 {
				 System.out.println(results.getName() + " @ " + LocalTime.now() + " SKIPPED");
			 }
			 
			URI parentPathLocation = null;
			Path parentPath = Paths.get(parentPathLocation);
		     try 
		     {
		    		    	 
			     //checks to see if parent directory does not exists.
		    	 if (!Files.exists(parentPath))
			     {
				     Files.createDirectories(parentPath);
			     }
			
			     //creates the test case folder name.
		    	 String testCaseSuite = results.getName();
			     String testCaseSuiteArray[] = testCaseSuite.split("_");
			     testCaseSuite = testCaseSuiteArray[0];
			     String testCasePathLocation = parentPathLocation + "\\" + testCaseSuite;
			     Path testCasePath = Paths.get(testCasePathLocation);
			     
			     //checks to see if working directory exists
			     //System.out.println(testCasePath);
			     if(!Files.exists(testCasePath)) 
			     {
			          Files.createDirectory(testCasePath);
			     }
			
			     String testCaseFolder = testCasePathLocation + "\\" + results.getName();
			     Path testCaseFolderPath = Paths.get(testCaseFolder);
			     
			     //checks to see if test case folder exists.
			     if(!Files.exists(testCaseFolderPath)) 
			     {
			
				     Files.createDirectory(testCaseFolderPath);
				 }
			
			    // creates a screen shot and send it to the folder.
			    File screenShotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			    String timeStamp = new SimpleDateFormat("YYYY_MM_dd_HH_mm_ss").format(new java.util.Date());
			    File destination = new File(testCaseFolderPath + "\\" + results.getName() + " " + timeStamp + ".png");
			    screenShotFile.renameTo(destination);
			    
			    Object captureLog = null;
				//captures logs
			    if(captureLog.equals("Y") || captureLog.equals("y"))
			    {
				    Runtime logGrabber = Runtime.getRuntime();
				    
				    String loginUrl = null;
					//parse the machine name for logger grabber
				    String [] serverNamePath = loginUrl.split("//");
				    String [] serverName = serverNamePath[1].split("/");
				    
				    try {
				    				    
				    	String logGrabberLocation = null;
						String logGrabberUserName = null;
						String logGrabberPWord = null;
						Process daLogs =  logGrabber.exec(logGrabberLocation + " " + serverName[0] + " " + 
				    	testCaseFolderPath.toAbsolutePath().toString() +"\\ " + logGrabberUserName + " " + logGrabberPWord);
				    	
					    //Allow enough time for logs to successfully copy over
					    daLogs.waitFor(5000, TimeUnit.MILLISECONDS);
				    }
				    catch(IllegalThreadStateException itse){
				    	System.out.println("Error with logs grabber");
				    }
			    }
				    //put logs into the error folder
			    
			    
		    }
		    catch (Exception e)
			{
				System.out.println("Directory could not be created");
			}
        }
		else if (results.getStatus() == ITestResult.SUCCESS)
		{
			System.out.println(results.getName() + " @ " + LocalTime.now() + " PASSED");
		}
		else
		{
			System.out.println(results.getName() + " @ " + LocalTime.now() + " NO TEST RESULT");
		}
	}
	
	
	
}

