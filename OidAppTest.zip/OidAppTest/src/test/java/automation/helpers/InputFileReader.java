package automation.helpers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class InputFileReader {
	

	
	public static String[] getFileValues(String filename) throws IOException {
	
	FileReader reader = new FileReader("src\\test\\java\\automation\\referencedata\\" + filename);
	BufferedReader br = new BufferedReader(reader);
	String line = "";
	List<String> listOfStrings
    = new ArrayList<String>();
	
//		 try {
//		            line = br.readLine();
//			} catch (FileNotFoundException e1) {
//				// TODO Auto-generated catch block
//				e1.printStackTrace();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//			}
//	 }
		

   
    // load data from file
		line = br.readLine();
   
    // checking for end of file
    while (line != null) {
        listOfStrings.add(line);
        line = br.readLine();
    }
   
    // closing bufferreader object
    br.close();
   
    // storing the data in arraylist to array
    String[] array
        = listOfStrings.toArray(new String[0]);
	return array;
   
	}
}

