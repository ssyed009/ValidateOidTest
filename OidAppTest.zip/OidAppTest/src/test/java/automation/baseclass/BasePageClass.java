package automation.baseclass;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class BasePageClass {
	/**
	 * Base page class that should be inherited in all page classes. Contains the methods and variables that are used in all page classes.             
	 */
		public WebDriver driver;
		public JavascriptExecutor js;
		public WebDriverWait wait;
		public static int ImplicitWaitTime;
		
		public BasePageClass(WebDriver driver)
		{
			this.driver = driver;
	        PageFactory.initElements(driver, this);
			this.js = ((JavascriptExecutor)driver);
			this.wait = new WebDriverWait(driver, ImplicitWaitTime);
		}
	
}
