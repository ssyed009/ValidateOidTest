package automation.baseclass;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.asserts.SoftAssert;
import automation.helpers.InputFileReader;
import automation.helpers.common;

/**
 * Base test class that should be inherited in all test classes. Contains the methods and variables that are used in all test classes.              
 */

public class BaseTestClass 
{
	public static WebDriver driver;
	public static Properties testdata = null;
	public static SoftAssert verify;
	public static InputFileReader fileReader;
	public static common commons;

	@BeforeSuite(alwaysRun = true)
	public void intializeTest() throws ClassNotFoundException, SQLException, IOException
	{	
	    
		//driver = new ChromeDriver();	
		common.setTestData();
	}

	@BeforeMethod(alwaysRun = true)
	public void startTestCase() throws SQLException, InterruptedException
	{	
		verify = new SoftAssert();
		

	}

	@AfterMethod(alwaysRun = true)
	public void EndTestCase(ITestResult results) throws IOException
	{
		common.createFailureReport(results,driver);
	}

	@AfterSuite(alwaysRun = true)
	public void endTest() throws SQLException
	{	
		//driver.quit();
	}

}

