package automation.tests;

import java.util.Properties;
import java.util.regex.Pattern;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import automation.baseclass.BaseTestClass;
import automation.helpers.InputFileReader;
import automation.helpers.common;


/**
 * This Automation test will check for various OID's. If the OID matches the trap from SNMP reference data file, the test passes.             
 */
public class ValidateOidTest extends BaseTestClass 
{
	/**
     * <dt><b>Test Case :</b> The purpose of this test case is to validate the OID <BR>
     * <dt><b>Test Steps :</b> 1-2 <BR>
	 * @throws Exception 
     */
	
	Properties prop = common.getPropertiesFile("\\src\\test\\java\\automation\\testdata\\testData.properties");
	String oid = "";
	Pattern pattern = Pattern.compile("((\\.)(\\d+))+");
	
	/**
	 * The purpose of this test is to verify that OID is a descendant.          
	 */
	
	@Test (description = "The Test checks if the input OID starts with expected prefix")
	public void valid_OID_Test() throws Exception
	{
		 oid = prop.getProperty("ValidOid");
		
		for(String str : InputFileReader.getFileValues("SNMPPrefix.txt")) {
			
			if(oid.startsWith(str)) {
			
				Assert.assertTrue(oid.startsWith(str), "The OID does not contains the expected prefix");
				Reporter.log(oid+" is valid, contains expected prefix.");
				break;
			}
				
		}
	}
	
	/**
	 * The purpose of this test is to check for blank/empty OID.          
	 */
	@Test (description = "The test case checks for a blank OID")
	public void Check_for_Blank_OID() throws Exception
	{
		
		oid = prop.getProperty("blankOid");
		verify.assertTrue(!oid.isBlank(), oid+" cannot to be empty.");
		Reporter.log(oid+" cannot to be empty.");
		
	}
	
	/**
	 * The purpose of this test is to check for non numeric OID.          
	 */
	@Test (description = "Check for non numeric character in an OID")
	public void Check_for_NonNumeric_Oid() throws Exception
	{
		
		oid = prop.getProperty("nonNumericOid");
		verify.assertTrue(oid.replace(".", "").matches("[0-9]+"), oid+" contains a invalid character.");
		Reporter.log(oid+" Contains a invalid character");
	}
	
	
	/**
	 * The purpose of this test is to check for last character of an OID.          
	 */
	@Test (description = "Check for last character in an OID")
	public void Check_for_LastChar_Oid() throws Exception
	{
		
		oid = prop.getProperty("lastCharOid");
		String[] ss = oid.split("");
		verify.assertTrue(ss[ss.length-1].matches("[0-9]+"), oid+" contains a invalid last character.");
		Reporter.log(oid+" contains a invalid last character.");
	}
	
	/**
	 * The purpose of this test is to check for first character of an OID.          
	 */
	@Test (description = "Check for first character in an OID")
	public void Check_for_FirstChar_Oid() throws Exception
	{
		
		oid = prop.getProperty("firstCharOid");
		String[] ss = oid.split("");
		verify.assertTrue(!ss[0].equals("."), oid+" Contains a invalid character.");
		Reporter.log(oid+" starts with an invalid character.");
	}
	
	/**
	 * The purpose of this test is to check for exact match of an OID to existing prefix.          
	 */
	@Test (description = "Check for exact match of OID")
	public void Check_for_Exact_Oid() throws Exception
	{
		
		oid = prop.getProperty("exactMatchOid");
		for(String str : InputFileReader.getFileValues("SNMPPrefix.txt")) {
			
			if(oid.startsWith(str)) {
			
				Assert.assertTrue(oid.equals(str), "The OID does not contains the expected prefix");
				Reporter.log(oid+" is an exact match of prefix.");
				break;
			}
		}
	}
	
	/**
	 * The purpose of this test is to check for max valid length OID assuming an OID can be no longer than 128 characters.        
	 */
	@Test (description = "Check for maximum length of OID")
	public void Check_for_Max_Oid_Length() throws Exception
	{
		
		oid = prop.getProperty("maxLengthOid");
		
		verify.assertTrue(oid.length()>128, oid+" is too long.");
		Reporter.log(oid+" is invalid, the length cannot exceed 128 characters.");
		//Assert.assertTrue(entitySearch.getSuccessMessage().contains("Document was posted successfully."), "Document did not post");
	}
	
	/**
	 * The purpose of this test is to check if a descendant is valid.        
	 */
	@Test
	public void Check_for_InvalidDescendant() throws Exception
	{
		
		oid = prop.getProperty("invalidDescendant");
		
		for(String str : InputFileReader.getFileValues("SNMPPrefix.txt")) {
			
			if(oid.startsWith(str) && oid.replace(".", "").matches("[0-9]+") && pattern.matcher(oid.trim()).matches()) {
				
				Assert.assertTrue(true, "The OID is an Invalid Descandant");
				break;
			}
			
			else
			verify.fail(oid+" is an Invalid Descendant.");
				
		}
		Reporter.log(oid+" is an Invalid Descendant.");
	}
	
	/**
	 * The purpose of this test is to check if a descendant is valid.        
	 */
	@Test
	public void Check_for_ValidDescendant() throws Exception
	{
		
		oid = prop.getProperty("validDescendant");
		
		for(String str : InputFileReader.getFileValues("SNMPPrefix.txt")) {
			
			if(oid.startsWith(str) && oid.replace(".", "").matches("[0-9]+") && pattern.matcher(oid.trim()).matches()) {
				
				Assert.assertTrue(true, "The OID is an Invalid Descandant");
				break;
			}
			
			else
			verify.fail(oid+" is an Invalid Descendant.");
				
		}
		Reporter.log(oid+" is a valid Descendant.");
	}
}
