package automation.tests;

import org.apache.commons.lang3.time.StopWatch;
import org.testng.Reporter;
import org.testng.annotations.Test;
import automation.baseclass.BaseTestClass;
import automation.helpers.InputFileReader;

public class ValidateBulkOid extends BaseTestClass{

	/**
     * <dt><b>Test Case :</b> The purpose of this test case is to get the file processing time for large file <BR>
	 * @throws Exception 
     */
	
	@Test (description = "Process large file")
	public void processBulkOid() throws Exception
	{
		StopWatch stopwatch = new StopWatch();
		stopwatch.start();
		for (String input : InputFileReader.getFileValues("SNMPLargeFile.txt")) {
			
			for(String str : InputFileReader.getFileValues("SNMPPrefix.txt")) {
				
				if(input.startsWith(str)) {
				
					verify.assertTrue(input.startsWith(str), "The OID does not contains the expected prefix");
				}
				
				else
					
					verify.fail("Oid doesnot contain prefix");
			}
			
		}
		stopwatch.stop();
		long x = stopwatch.getTime();
		// Convert the result to a string
		String numberAsString = Long.toString(x);
		Reporter.log("Execution time- " + numberAsString+ " milliseconds \n");
	}
}
